<?php

define("HOST", "localhost");     // The host you want to connect to.
define("USER", "fotinfo_tchris");    // The database username. 
define("PASSWORD", "EM420CTU");    // The database password. 
define("DATABASE", "fotinfo_tchris");    // The database name.

// Create connection
$mysqli = mysqli_connect(HOST, USER, PASSWORD, DATABASE);

// Check connection
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
